package ar.optimoto

import android.content.Context
import java.io.File
import java.io.IOException

object Optimizer {
    private val protect = listOf("com.android.systemui", "com.android.phone", "com.android.launcher",
        "com.motorola.launcher", "com.google.android.inputmethod", "android.", "vendor.", "system", "media.")

    private class P(val pid: Int, val uid: Int, val rssKb: Long, val name: String)
    class Stats(val memPsi: Double, val cpu: Double?)

    private fun kb(key: String): Long = File("/proc/meminfo").readLines()
        .firstOrNull { it.startsWith("$key:") }?.filter { it.isDigit() }?.toLongOrNull() ?: 0L

    fun freeMb(): Long = kb("MemAvailable") / 1024

    fun statusLine(): String {
        val swapT = kb("SwapTotal") / 1024
        val swapU = swapT - kb("SwapFree") / 1024
        return "RAM libre ${freeMb()} / ${kb("MemTotal") / 1024} MB · zRAM/swap usado $swapU / $swapT MB"
    }

    fun ensure(ctx: Context): Adb {
        val adb = Adb.get(ctx)
        if (!adb.isConnected) adb.connectTls(ctx.applicationContext, 8000)
        if (!adb.isConnected) throw IllegalStateException("Sin conexión ADB (activá Depuración inalámbrica y conectá)")
        return adb
    }

    /** Ejecuta un comando y, si la conexión se cayó (cambio de Wi-Fi, etc.), reconecta y reintenta una vez. */
    fun sh(ctx: Context, cmd: String): String = try {
        ensure(ctx).sh(cmd)
    } catch (e: IOException) {
        try { Adb.get(ctx).disconnect() } catch (_: Exception) {}
        ensure(ctx).sh(cmd)
    }

    /** Presión de memoria (PSI, la señal real de "se siente lento") y uso de CPU. */
    fun stats(ctx: Context): Stats? = try {
        val o = sh(ctx, "cat /proc/pressure/memory; echo ===; dumpsys cpuinfo | grep -m1 TOTAL").split("===")
        Stats(
            Regex("""some avg10=([\d.]+)""").find(o[0])?.groupValues?.get(1)?.toDouble() ?: 0.0,
            Regex("""([\d.]+)% TOTAL""").find(o.getOrElse(1) { "" })?.groupValues?.get(1)?.toDouble()
        )
    } catch (e: Exception) { null }

    /**
     * Libera RAM sin matar nada. Según oom_score_adj de cada proceso:
     *  - < 100 (en pantalla/primer plano): no se toca.
     *  - 100–299 (servicios en primer plano: traductor, womic, música): solo recorte suave.
     *  - >= 300 (segundo plano/caché): recorte + compactación (am compact) de los que más pesan.
     * Las apps protegidas reciben siempre la versión suave.
     */
    fun run(ctx: Context, aggressive: Boolean, kill: Boolean): String {
        val sp = ctx.getSharedPreferences("p", 0)
        val ex = sp.getStringSet("ex", emptySet())!!
        val before = freeMb()
        val top = Regex("""\s([\w.]+)/""").find(sh(ctx, "dumpsys activity activities | grep -m1 topResumedActivity"))?.groupValues?.get(1)
        val rows = sh(ctx, "ps -A -o PID,UID,RSS,NAME").lines().mapNotNull { l ->
            val t = l.trim().split(Regex("\\s+"), 4)
            val pid = t.getOrNull(0)?.toIntOrNull(); val uid = t.getOrNull(1)?.toIntOrNull(); val rss = t.getOrNull(2)?.toLongOrNull()
            val name = t.getOrNull(3)?.trim()
            if (pid == null || uid == null || rss == null || name == null || uid < 10000) null else P(pid, uid, rss, name)
        }.filter { p ->
            p.name.contains('.') && !p.name.contains(' ') && protect.none { p.name.startsWith(it) } &&
                p.name.substringBefore(':') != top && p.name.substringBefore(':') != ctx.packageName
        }.sortedByDescending { it.rssKb }
        val adj = sh(ctx, "for p in ${rows.joinToString(" ") { it.pid.toString() }}; do echo \$p \$(cat /proc/\$p/oom_score_adj 2>/dev/null); done")
            .lines().mapNotNull { l ->
                val t = l.trim().split(" ")
                val p = t.getOrNull(0)?.toIntOrNull(); val a = t.getOrNull(1)?.toIntOrNull()
                if (p != null && a != null) p to a else null
            }.toMap()
        val cmds = mutableListOf<String>()
        var trimmed = 0; var compacted = 0
        for (p in rows) {
            val a = adj[p.pid] ?: 900
            val prot = p.name.substringBefore(':') in ex
            if (a < 100) continue
            if (a < 300) { cmds += "am send-trim-memory --user 0 ${p.name} BACKGROUND"; trimmed++; continue }
            val lvl = if (prot) "BACKGROUND" else if (aggressive) "COMPLETE" else "MODERATE"
            cmds += "am send-trim-memory --user 0 ${p.name} $lvl"; trimmed++
            if (p.rssKb > 30_000 && compacted < 25) {
                cmds += "am compact ${if (prot) "some" else "full"} ${p.name} ${p.uid}"; compacted++
            }
        }
        cmds.chunked(8).forEach { sh(ctx, it.joinToString(";")) }
        if (kill) rows.filter { (adj[it.pid] ?: 0) >= 900 && it.name.substringBefore(':') !in ex }
            .map { it.name.substringBefore(':') }.distinct().chunked(20)
            .forEach { ch -> sh(ctx, ch.joinToString(";") { "am kill $it" }) }
        Thread.sleep(3000)
        return "recortados $trimmed · compactados $compacted · RAM libre $before → ${freeMb()} MB"
    }

    /** Compila una app a código nativo: instalar/desinstalar mucho las deja "interpretadas" y lentas. */
    fun compilePackage(ctx: Context, pkg: String) { sh(ctx, "cmd package compile -m speed -f $pkg") }

    fun animations(ctx: Context, fast: Boolean) {
        val v = if (fast) "0.5" else "1"
        sh(ctx, "settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v")
    }
}
