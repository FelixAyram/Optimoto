package ar.optimoto

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class OptWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(c, "⚡ Optimizar"))
    }

    companion object {
        fun views(c: Context, text: String) = RemoteViews(c.packageName, R.layout.widget).apply {
            setTextViewText(R.id.wtxt, text)
            setOnClickPendingIntent(R.id.wroot, PendingIntent.getForegroundService(c, 1,
                Intent(c, AutoService::class.java).setAction("OPT_NOW"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }

        fun update(c: Context, text: String) {
            AppWidgetManager.getInstance(c).updateAppWidget(ComponentName(c, OptWidget::class.java), views(c, text))
        }
    }
}
