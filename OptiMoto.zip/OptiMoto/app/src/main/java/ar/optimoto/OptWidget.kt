package ar.optimoto

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews

/** Widget adaptable: según el tamaño que le des muestra solo el número, número + barra, o todo. */
class OptWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(c, m, id, null))
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        m.updateAppWidget(id, views(c, m, id, null))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACT) {
            update(c, "Optimizando…")
            try { c.startForegroundService(Intent(c, AutoService::class.java).setAction("OPT_NOW")) }
            catch (e: Exception) { update(c, "No se pudo iniciar: ${e.message}".take(60)) }
        }
    }

    companion object {
        const val ACT = "ar.optimoto.WIDGET_OPT"

        fun views(c: Context, m: AppWidgetManager, id: Int, msg: String?): RemoteViews {
            val o = m.getAppWidgetOptions(id)
            val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180).let { if (it > 0) it else 180 }
            val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 70).let { if (it > 0) it else 70 }
            val d = c.resources.displayMetrics.density
            val total = Optimizer.totalMb(); val free = Optimizer.freeMb()
            val sp = c.getSharedPreferences("p", 0)
            val at = sp.getLong("lastAt", 0L)
            val last = if (at == 0L) "Tocá para optimizar" else {
                val min = (System.currentTimeMillis() - at) / 60000
                "Última: ${sp.getString("lastTxt", "")} · " + (if (min < 1) "recién" else "hace $min min")
            }
            val tight = w < 100
            val showLast = h >= 90 && w >= 150
            val pad = ((h * 0.12f).coerceIn(5f, 14f) * d).toInt()
            val size = minOf(h * 0.30f, w * (if (tight) 0.24f else 0.15f)).coerceIn(13f, 34f)
            return RemoteViews(c.packageName, R.layout.widget).apply {
                // sin lugar para el mensaje: el estado se muestra en el número
                val big = when {
                    msg != null && !showLast -> if (msg.endsWith("…")) "…" else "Error"
                    tight -> Optimizer.fmtShort(free)
                    else -> Optimizer.fmt(free)
                }
                setTextViewText(R.id.w_free, big)
                setTextViewTextSize(R.id.w_free, TypedValue.COMPLEX_UNIT_SP, size)
                setTextViewText(R.id.w_sub, "libres de ${Optimizer.fmt(total)}")
                setViewVisibility(R.id.w_sub, if (w >= 150) View.VISIBLE else View.GONE)
                setProgressBar(R.id.w_bar, 100, if (total > 0) ((total - free) * 100 / total).toInt() else 0, false)
                setViewVisibility(R.id.w_bar, if (h >= 56) View.VISIBLE else View.GONE)
                setTextViewText(R.id.w_last, msg ?: last)
                setViewVisibility(R.id.w_last, if (showLast) View.VISIBLE else View.GONE)
                setViewPadding(R.id.w_root, pad, pad, pad, pad)
                setOnClickPendingIntent(R.id.w_root, PendingIntent.getBroadcast(c, 1,
                    Intent(c, OptWidget::class.java).setAction(ACT), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            }
        }

        fun update(c: Context, msg: String? = null) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, OptWidget::class.java))) m.updateAppWidget(id, views(c, m, id, msg))
        }
    }
}
