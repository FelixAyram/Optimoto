package ar.optimoto

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class OptWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(c, null))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACT) {
            update(c, "Optimizando…")
            try { c.startForegroundService(Intent(c, AutoService::class.java).setAction("OPT_NOW")) }
            catch (e: Exception) { update(c, "No se pudo iniciar: ${e.message}".take(60)) }
        }
    }

    companion object {
        const val ACT = "ar.optimoto.WIDGET_OPT"

        fun views(c: Context, msg: String?): RemoteViews {
            val total = Optimizer.totalMb(); val free = Optimizer.freeMb()
            val sp = c.getSharedPreferences("p", 0)
            val at = sp.getLong("lastAt", 0L)
            val last = if (at == 0L) "Tocá para optimizar" else {
                val m = (System.currentTimeMillis() - at) / 60000
                "Última: ${sp.getString("lastTxt", "")} · " + (if (m < 1) "recién" else "hace $m min")
            }
            return RemoteViews(c.packageName, R.layout.widget).apply {
                setTextViewText(R.id.w_free, Optimizer.fmt(free))
                setTextViewText(R.id.w_sub, "libres de ${Optimizer.fmt(total)}")
                setProgressBar(R.id.w_bar, 100, if (total > 0) ((total - free) * 100 / total).toInt() else 0, false)
                setTextViewText(R.id.w_last, msg ?: last)
                setOnClickPendingIntent(R.id.w_root, PendingIntent.getBroadcast(c, 1,
                    Intent(c, OptWidget::class.java).setAction(ACT), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            }
        }

        fun update(c: Context, msg: String? = null) {
            AppWidgetManager.getInstance(c).updateAppWidget(ComponentName(c, OptWidget::class.java), views(c, msg))
        }
    }
}
