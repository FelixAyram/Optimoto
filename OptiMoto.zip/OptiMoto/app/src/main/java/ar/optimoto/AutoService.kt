package ar.optimoto

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import kotlin.concurrent.thread

/** Vigía liviano: umbrales de RAM/CPU, cierre periódico, limpieza al apagar pantalla, compilar apps nuevas y widget. */
class AutoService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val sp by lazy { getSharedPreferences("p", 0) }
    @Volatile private var busy = false
    @Volatile private var checking = false
    private var last = 0L
    private var lastClose = 0L
    private var rx = false

    private val tick = object : Runnable {
        override fun run() { onTick(); h.postDelayed(this, 30000) }
    }

    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            if (pkg == packageName || !sp.getBoolean("newcomp", true)) return
            thread {
                try { Thread.sleep(20000); Optimizer.compilePackage(this@AutoService, pkg); note("Compilada: $pkg") } catch (_: Throwable) {}
            }
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!sp.getBoolean("screenoff", false)) return
            h.postDelayed({
                if (!getSystemService(PowerManager::class.java).isInteractive && System.currentTimeMillis() - last > 180000)
                    optimize("pantalla apagada", false)
            }, 8000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun keep() = sp.getBoolean("auto", false) || sp.getBoolean("closeOn", false)

    private fun notif(t: String) = Notification.Builder(this, "auto").setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("OptiMoto").setContentText(t).setOngoing(true).build()

    private fun note(t: String) = getSystemService(NotificationManager::class.java).notify(11, notif(t))

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("auto", "Optimización automática", NotificationManager.IMPORTANCE_MIN))
        startForeground(11, notif("Activo"))
        h.removeCallbacks(tick)
        if (lastClose == 0L) lastClose = System.currentTimeMillis()
        if (keep()) {
            h.postDelayed(tick, 5000)
            if (!rx) {
                registerReceiver(pkgRx, IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") })
                registerReceiver(screenRx, IntentFilter(Intent.ACTION_SCREEN_OFF))
                rx = true
            }
        }
        if (i?.action == "OPT_NOW") optimize("manual", true) else if (!keep()) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        if (rx) {
            try { unregisterReceiver(pkgRx) } catch (_: Exception) {}
            try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); if (!busy) Runtime.getRuntime().gc() }

    private fun onTick() {
        val on = getSystemService(PowerManager::class.java).isInteractive
        if (on) OptWidget.update(this)
        if (busy || checking) return
        checking = true
        thread {
            try {
                val now = System.currentTimeMillis()
                if (sp.getBoolean("closeOn", false) && now - lastClose >= sp.getInt("closeMin", 30) * 60_000L) {
                    lastClose = now
                    job(false, "Cerrando apps") { Optimizer.forceClose(this) }
                } else if (on && sp.getBoolean("auto", false) && now - last > 180000) {
                    val free = Optimizer.freeMb()
                    var why: String? = if (free < sp.getInt("ram", 700)) "RAM libre $free MB" else null
                    if (why == null && Adb.isUp()) {
                        val st = Optimizer.stats(this)
                        if (st != null) {
                            if (st.memPsi > sp.getInt("psi", 10)) why = "presión de memoria ${st.memPsi}%"
                            else if ((st.cpu ?: 0.0) > sp.getInt("cpu", 90)) why = "CPU ${st.cpu}%"
                        }
                    }
                    if (why != null) optimize(why, false)
                }
            } catch (_: Throwable) {} finally { checking = false }
        }
    }

    private fun optimize(why: String, manual: Boolean) = job(manual, "Optimizando") {
        last = System.currentTimeMillis()
        "$why → " + Optimizer.run(this, sp.getBoolean("agr", false), sp.getBoolean("kill", false))
    }

    private fun job(manual: Boolean, label: String, block: () -> String) {
        if (busy) return
        busy = true
        OptWidget.update(this, "$label…")
        thread {
            val msg = try { block() } catch (e: Throwable) { "Error: ${e.message}" }
            busy = false
            OptWidget.update(this, if (msg.startsWith("Error")) msg.take(60) else null)
            note(msg)
            Runtime.getRuntime().gc()
            if (manual && !keep()) stopSelf()
        }
    }
}
