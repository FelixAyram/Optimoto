package ar.optimoto

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import kotlin.concurrent.thread

/** Vigila RAM / presión de memoria / CPU y libera al pasar el umbral; atiende el widget y compila apps nuevas. */
class AutoService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val sp by lazy { getSharedPreferences("p", 0) }
    @Volatile private var busy = false
    @Volatile private var checking = false
    private var last = 0L
    private var rxOn = false

    private val tick = object : Runnable {
        override fun run() { check(); h.postDelayed(this, 30000) }
    }

    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            if (pkg == packageName || !sp.getBoolean("newcomp", true)) return
            thread {
                try { Thread.sleep(20000); Optimizer.compilePackage(this@AutoService, pkg); note("Compilada: $pkg") } catch (_: Throwable) {}
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(t: String) = Notification.Builder(this, "auto").setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("OptiMoto").setContentText(t).setOngoing(true).build()

    private fun note(t: String) = getSystemService(NotificationManager::class.java).notify(11, notif(t))

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("auto", "Optimización automática", NotificationManager.IMPORTANCE_MIN))
        startForeground(11, notif("Vigilando RAM y CPU"))
        h.removeCallbacks(tick)
        val auto = sp.getBoolean("auto", false)
        if (auto) {
            h.postDelayed(tick, 5000)
            if (!rxOn) {
                registerReceiver(pkgRx, IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") })
                rxOn = true
            }
        }
        if (i?.action == "OPT_NOW") work(true, "manual") else if (!auto) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        if (rxOn) try { unregisterReceiver(pkgRx) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun check() {
        if (busy || checking) return
        if (!getSystemService(PowerManager::class.java).isInteractive) return   // pantalla apagada: no hace falta
        checking = true
        thread {
            try {
                val free = Optimizer.freeMb()
                var why: String? = if (free < sp.getInt("ram", 700)) "RAM libre $free MB" else null
                if (why == null) {
                    val st = Optimizer.stats(this)
                    if (st != null) {
                        if (st.memPsi > sp.getInt("psi", 10)) why = "presión de memoria ${st.memPsi}%"
                        else if ((st.cpu ?: 0.0) > sp.getInt("cpu", 90)) why = "CPU ${st.cpu}%"
                    }
                }
                if (why != null && System.currentTimeMillis() - last > 180000) work(false, why)
            } catch (_: Throwable) {} finally { checking = false }
        }
    }

    private fun work(manual: Boolean, why: String) {
        if (busy) return
        busy = true
        thread {
            val msg = try {
                "$why → " + Optimizer.run(this, sp.getBoolean("agr", false), sp.getBoolean("kill", false))
            } catch (e: Throwable) { "⚠ ${e.message}" }
            last = System.currentTimeMillis()
            busy = false
            OptWidget.update(this, if (msg.startsWith("⚠")) msg.take(40) else "⚡ " + msg.substringAfterLast("· ").take(36))
            note(msg)
            if (manual && !sp.getBoolean("auto", false)) stopSelf()
        }
    }
}
