package ar.optimoto

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.IBinder
import io.github.muntashirakon.adb.android.AdbMdns

/** Busca el puerto de emparejado por mDNS y pide el código desde una notificación. */
class PairService : Service() {
    private var mdns: AdbMdns? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(ID, build(this, "Abrí Depuración inalámbrica › Vincular dispositivo con código", null, -1))
        mdns?.stop()
        mdns = AdbMdns(this, AdbMdns.SERVICE_TYPE_TLS_PAIRING) { host, port ->
            if (port > 0) getSystemService(NotificationManager::class.java).notify(
                ID, build(this, "Puerto $port detectado. Escribí el código de 6 dígitos:", host?.hostAddress ?: "127.0.0.1", port))
        }
        mdns?.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() { mdns?.stop(); super.onDestroy() }

    companion object {
        const val ID = 7
        const val RESULT_ID = 8
        private const val CH = "pair"

        fun build(c: Context, text: String, host: String?, port: Int, ongoing: Boolean = true): Notification {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Emparejado ADB", NotificationManager.IMPORTANCE_HIGH))
            val b = Notification.Builder(c, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("OptiMoto").setContentText(text).setOngoing(ongoing).setAutoCancel(!ongoing)
                .setContentIntent(PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            if (host != null && port > 0) {
                val pi = PendingIntent.getBroadcast(c, 0,
                    Intent(c, PairReceiver::class.java).putExtra("host", host).putExtra("port", port),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                val ri = RemoteInput.Builder("code").setLabel("Código de 6 dígitos").build()
                b.addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send),
                    "Ingresar código", pi).addRemoteInput(ri).build())
            }
            return b.build()
        }
    }
}
