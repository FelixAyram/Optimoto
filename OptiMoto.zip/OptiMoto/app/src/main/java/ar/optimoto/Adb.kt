package ar.optimoto

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import java.io.File
import java.security.Security
import org.conscrypt.Conscrypt
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random
import android.sun.security.x509.AlgorithmId
import android.sun.security.x509.CertificateAlgorithmId
import android.sun.security.x509.CertificateExtensions
import android.sun.security.x509.CertificateIssuerName
import android.sun.security.x509.CertificateSerialNumber
import android.sun.security.x509.CertificateSubjectName
import android.sun.security.x509.CertificateValidity
import android.sun.security.x509.CertificateVersion
import android.sun.security.x509.CertificateX509Key
import android.sun.security.x509.KeyIdentifier
import android.sun.security.x509.PrivateKeyUsageExtension
import android.sun.security.x509.SubjectKeyIdentifierExtension
import android.sun.security.x509.X500Name
import android.sun.security.x509.X509CertImpl
import android.sun.security.x509.X509CertInfo

/** Conexión ADB inalámbrica (emparejado con código) contra el propio teléfono. */
class Adb(ctx: Context) : AbsAdbConnectionManager() {
    companion object {
        @Volatile private var inst: Adb? = null
        fun get(c: Context): Adb = inst ?: synchronized(this) {
            inst ?: run {
                Security.insertProviderAt(Conscrypt.newProvider(), 1)
                Adb(c.applicationContext).also { inst = it }
            }
        }
    }

    private val kf = File(ctx.filesDir, "k.pk8")
    private val cf = File(ctx.filesDir, "c.der")
    private lateinit var pk: PrivateKey
    private lateinit var ct: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        if (!kf.exists() || !cf.exists()) gen()
        pk = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
        ct = CertificateFactory.getInstance("X.509").generateCertificate(cf.inputStream())
    }

    private fun gen() {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048, SecureRandom.getInstance("SHA1PRNG"))
        val kp = kpg.generateKeyPair()
        val algo = "SHA512withRSA"
        val notBefore = Date()
        val notAfter = Date(notBefore.time + 3650L * 24 * 3600 * 1000)
        val ext = CertificateExtensions()
        ext.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(kp.public).identifier))
        val name = X500Name("CN=OptiMoto")
        ext.set("PrivateKeyUsage", PrivateKeyUsageExtension(notBefore, notAfter))
        val info = X509CertInfo()
        info.set("version", CertificateVersion(2))
        info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
        info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(algo)))
        info.set("subject", CertificateSubjectName(name))
        info.set("key", CertificateX509Key(kp.public))
        info.set("validity", CertificateValidity(notBefore, notAfter))
        info.set("issuer", CertificateIssuerName(name))
        info.set("extensions", ext)
        val cert = X509CertImpl(info)
        cert.sign(kp.private, algo)
        kf.writeBytes(kp.private.encoded)
        cf.writeBytes(cert.encoded)
    }

    override fun getPrivateKey(): PrivateKey = pk
    override fun getCertificate(): Certificate = ct
    override fun getDeviceName(): String = "OptiMoto"

    fun sh(cmd: String): String {
        val st = openStream("shell:$cmd")
        try { return st.openInputStream().bufferedReader().readText() } finally { st.close() }
    }
}
