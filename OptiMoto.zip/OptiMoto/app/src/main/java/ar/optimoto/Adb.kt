package ar.optimoto

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import sun.security.x509.AlgorithmId
import sun.security.x509.CertificateAlgorithmId
import sun.security.x509.CertificateExtensions
import sun.security.x509.CertificateSerialNumber
import sun.security.x509.CertificateValidity
import sun.security.x509.CertificateVersion
import sun.security.x509.CertificateX509Key
import sun.security.x509.KeyIdentifier
import sun.security.x509.SubjectKeyIdentifierExtension
import sun.security.x509.X500Name
import sun.security.x509.X509CertImpl
import sun.security.x509.X509CertInfo

/** Conexión ADB inalámbrica (emparejado con código) contra el propio teléfono. */
class Adb(ctx: Context) : AbsAdbConnectionManager() {
    private val kf = File(ctx.filesDir, "k.pk8")
    private val cf = File(ctx.filesDir, "c.der")
    private lateinit var pk: PrivateKey
    private lateinit var ct: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        if (!kf.exists() || !cf.exists()) gen()
        pk = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
        ct = CertificateFactory.getInstance("X.509").generateCertificate(cf.inputStream())
    }

    private fun gen() {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048, SecureRandom.getInstance("SHA1PRNG")) }.generateKeyPair()
        val algo = AlgorithmId.get("SHA512withRSA")
        val from = Date(); val to = Date(from.time + 3650L * 24 * 3600 * 1000)
        val name = X500Name("CN=OptiMoto")
        val ext = CertificateExtensions()
        ext.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(kp.public).identifier))
        val info = X509CertInfo().apply {
            set(X509CertInfo.VERSION, CertificateVersion(CertificateVersion.V3))
            set(X509CertInfo.SERIAL_NUMBER, CertificateSerialNumber(SecureRandom().nextInt() and Int.MAX_VALUE))
            set(X509CertInfo.ALGORITHM_ID, CertificateAlgorithmId(algo))
            set(X509CertInfo.SUBJECT, name); set(X509CertInfo.ISSUER, name)
            set(X509CertInfo.KEY, CertificateX509Key(kp.public))
            set(X509CertInfo.VALIDITY, CertificateValidity(from, to))
            set(X509CertInfo.EXTENSIONS, ext)
        }
        val cert = X509CertImpl(info).also { it.sign(kp.private, "SHA512withRSA") }
        kf.writeBytes(kp.private.encoded); cf.writeBytes(cert.encoded)
    }

    override fun getPrivateKey(): PrivateKey = pk
    override fun getCertificate(): Certificate = ct
    override fun getDeviceName(): String = "OptiMoto"

    fun sh(cmd: String): String {
        val st = openStream("shell:$cmd")
        try { return st.openInputStream().bufferedReader().readText() } finally { st.close() }
    }
}
