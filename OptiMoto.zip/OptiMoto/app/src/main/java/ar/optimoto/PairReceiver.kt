package ar.optimoto

import android.app.NotificationManager
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlin.concurrent.thread

class PairReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = RemoteInput.getResultsFromIntent(i)?.getCharSequence("code")?.toString()?.trim() ?: return
        val host = i.getStringExtra("host") ?: "127.0.0.1"
        val port = i.getIntExtra("port", -1)
        val app = c.applicationContext
        val pending = goAsync()
        thread {
            val nm = app.getSystemService(NotificationManager::class.java)
            try {
                val adb = Adb.get(app)
                adb.pair(host, port, code)
                adb.connectTls(app, 10000)
                app.stopService(Intent(app, PairService::class.java))
                nm.notify(PairService.RESULT_ID, PairService.build(app, "✅ Emparejado y conectado. Volvé a OptiMoto.", null, -1, false))
            } catch (e: Throwable) {
                nm.notify(PairService.ID, PairService.build(app, "❌ ${e.message}. Revisá el código y reintentá:", host, port))
            }
            pending.finish()
        }
    }
}
