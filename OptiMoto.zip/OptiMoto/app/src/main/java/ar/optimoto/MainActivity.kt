package ar.optimoto

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import org.conscrypt.Conscrypt
import java.io.File
import java.security.Security
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var adb: Adb
    private lateinit var log: TextView
    private lateinit var swAgr: Switch
    private lateinit var swKill: Switch
    private val sp by lazy { getSharedPreferences("p", 0) }
    private val protect = listOf("com.android.systemui", "com.android.phone", "com.android.launcher",
        "com.motorola.launcher", "com.google.android.inputmethod", "android.", "vendor.", "system", "media.")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
        adb = Adb(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        fun et(h: String, key: String) = EditText(this).apply {
            hint = h; inputType = InputType.TYPE_CLASS_NUMBER; setText(sp.getString(key, ""))
        }
        val pPair = et("Puerto de emparejado", "pp"); val code = et("Código de 6 dígitos", "")
        val pConn = et("Puerto de conexión (pantalla principal de Depuración inalámbrica)", "pc")
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        swAgr = Switch(this).apply { text = "Liberación agresiva" }
        swKill = Switch(this).apply { text = "Cerrar procesos en caché (salvo protegidas)" }
        log = TextView(this).apply { textSize = 13f }
        listOf<View>(pPair, code, pConn,
            btn("1) Emparejar") {
                sp.edit().putString("pp", pPair.text.toString()).apply()
                bg { val ok = adb.pair("127.0.0.1", pPair.text.toString().toInt(), code.text.toString()); say("Emparejado: $ok") }
            },
            btn("2) Conectar") {
                sp.edit().putString("pc", pConn.text.toString()).apply()
                bg { say("Conectado: " + adb.connect("127.0.0.1", pConn.text.toString().toInt())) }
            },
            swAgr, swKill,
            btn("⚡ Optimizar RAM ahora") { val a = swAgr.isChecked; val k = swKill.isChecked; bg { optimize(a, k) } },
            btn("🔧 Recompilar apps (dexopt)") { bg { compile() } },
            btn("🛡 Apps protegidas") { pickExcluded() }
        ).forEach { root.addView(it) }
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)
        say("RAM libre: ${freeMb()} MB")
    }

    private fun bg(f: () -> Unit) = thread { try { f() } catch (e: Throwable) { say("Error: ${e.message}") } }
    private fun say(s: String) = runOnUiThread { log.append(s + "\n") }
    private fun freeMb(): Long = File("/proc/meminfo").readLines()
        .first { it.startsWith("MemAvailable") }.filter { it.isDigit() }.toLong() / 1024

    private fun optimize(aggressive: Boolean, kill: Boolean) {
        val before = freeMb()
        val top = Regex("""\s([\w.]+)/""").find(adb.sh("dumpsys activity activities | grep -m1 topResumedActivity"))?.groupValues?.get(1)
        val ex = sp.getStringSet("ex", emptySet())!!
        val procs = adb.sh("ps -A -o NAME").lines().map { it.trim() }.filter { p ->
            p.contains('.') && !p.contains(' ') && !p.startsWith("/") && !p.startsWith("[") &&
                protect.none { p.startsWith(it) } && p.substringBefore(':') != top && p.substringBefore(':') != packageName
        }.distinct()
        // Nunca mata: pide a cada app que suelte memoria. Las protegidas reciben solo un recorte suave.
        procs.chunked(20).forEach { ch ->
            adb.sh(ch.joinToString(";") { p ->
                val lvl = if (p.substringBefore(':') in ex) "BACKGROUND" else if (aggressive) "COMPLETE" else "MODERATE"
                "am send-trim-memory --user 0 $p $lvl"
            })
        }
        if (kill) procs.map { it.substringBefore(':') }.distinct().filter { it !in ex }
            .chunked(20).forEach { ch -> adb.sh(ch.joinToString(";") { "am kill $it" }) }
        Thread.sleep(2500)
        say("${procs.size} procesos recortados. RAM libre: $before → ${freeMb()} MB")
    }

    private fun compile() {
        say("Compilando apps… dejá el cel cargando, tarda varios minutos.")
        adb.sh("cmd package compile -m speed-profile -a")
        say("Listo.")
    }

    private fun pickExcluded() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinct().sortedBy { it.second.lowercase() }
        val ex = sp.getStringSet("ex", emptySet())!!.toMutableSet()
        AlertDialog.Builder(this).setTitle("Apps protegidas (nunca se cierran)")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in ex }) { _, i, c ->
                if (c) ex += apps[i].first else ex -= apps[i].first
            }
            .setPositiveButton("Guardar") { _, _ -> sp.edit().putStringSet("ex", ex).apply() }.show()
    }
}
