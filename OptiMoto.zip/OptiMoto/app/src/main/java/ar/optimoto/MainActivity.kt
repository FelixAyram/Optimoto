package ar.optimoto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var swAgr: Switch
    private lateinit var swKill: Switch
    private lateinit var swAuto: Switch
    private lateinit var swNew: Switch
    private lateinit var swFast: Switch
    private lateinit var etRam: EditText
    private lateinit var etPsi: EditText
    private lateinit var etCpu: EditText
    private val sp by lazy { getSharedPreferences("p", 0) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun num(h: String, k: String, d: Int) = EditText(this).apply {
            hint = h; inputType = InputType.TYPE_CLASS_NUMBER; setText(sp.getInt(k, d).toString())
        }
        fun sw(t: String, k: String, d: Boolean) = Switch(this).apply { text = t; isChecked = sp.getBoolean(k, d) }
        status = TextView(this).apply { textSize = 14f }
        swAgr = sw("Liberación agresiva", "agr", false)
        swKill = sw("Cerrar procesos en caché (salvo protegidas)", "kill", false)
        swAuto = sw("Modo automático (vigila RAM, presión y CPU)", "auto", false)
        swNew = sw("Compilar apps nuevas al instalarlas", "newcomp", true)
        swFast = sw("Animaciones rápidas (0.5x)", "fast", false)
        etRam = num("Liberar si RAM libre menor a (MB)", "ram", 700)
        etPsi = num("o si la presión de memoria supera (%)", "psi", 10)
        etCpu = num("o si el CPU supera (%)", "cpu", 90)
        log = TextView(this).apply { textSize = 13f }
        listOf<View>(status,
            btn("1) Emparejar (abre ajustes)") {
                startForegroundService(Intent(this, PairService::class.java))
                say("Activá Depuración inalámbrica y tocá «Vincular dispositivo con código». Saldrá una notificación para escribir el código.")
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { say("Abrí Ajustes › Opciones de desarrollador a mano.") }
            },
            btn("2) Conectar") { bg { Optimizer.ensure(this); say("Conectado ✅") } },
            swAgr, swKill, swAuto, etRam, etPsi, etCpu, swNew, swFast,
            btn("⚡ Optimizar RAM ahora") { saveCfg(); bg { say("Optimizando…"); say(Optimizer.run(this, swAgr.isChecked, swKill.isChecked)); refresh() } },
            btn("🔍 Diagnóstico") { bg { diag() } },
            btn("🔧 Recompilar TODAS las apps (lento)") { bg { say("Compilando… dejá el cel cargando, tarda varios minutos."); Optimizer.sh(this, "cmd package compile -m speed-profile -a"); say("Listo.") } },
            btn("🛡 Apps protegidas") { pickExcluded() },
            TextView(this).apply { text = "Widget: mantené apretada la pantalla de inicio › Widgets › OptiMoto."; textSize = 12f }
        ).forEach { root.addView(it) }
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)
        swAuto.setOnCheckedChangeListener { _, on ->
            saveCfg()
            if (on) startForegroundService(Intent(this, AutoService::class.java)) else stopService(Intent(this, AutoService::class.java))
        }
        swFast.setOnCheckedChangeListener { _, on -> saveCfg(); bg { Optimizer.animations(this, on); say(if (on) "Animaciones a 0.5x" else "Animaciones normales") } }
        if (swAuto.isChecked) startForegroundService(Intent(this, AutoService::class.java))
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { saveCfg(); super.onPause() }

    private fun refresh() = runOnUiThread { status.text = Optimizer.statusLine() }

    private fun saveCfg() {
        sp.edit().putBoolean("agr", swAgr.isChecked).putBoolean("kill", swKill.isChecked).putBoolean("auto", swAuto.isChecked)
            .putBoolean("newcomp", swNew.isChecked).putBoolean("fast", swFast.isChecked)
            .putInt("ram", etRam.text.toString().toIntOrNull() ?: 700).putInt("psi", etPsi.text.toString().toIntOrNull() ?: 10)
            .putInt("cpu", etCpu.text.toString().toIntOrNull() ?: 90).apply()
    }

    private fun diag() {
        say(Optimizer.statusLine())
        val st = Optimizer.stats(this)
        say("Presión de memoria: ${st?.memPsi ?: "n/d"}% · CPU: ${st?.cpu ?: "n/d"}%")
        val top = Optimizer.sh(this, "ps -A -o RSS,NAME | sort -rn | head -8").lines().mapNotNull { l ->
            val t = l.trim().split(Regex("\\s+"), 2); val kb = t.getOrNull(0)?.toLongOrNull()
            if (kb != null && t.size == 2) "${kb / 1024} MB  ${t[1]}" else null
        }
        say("Más pesados:\n" + top.joinToString("\n"))
    }

    private fun bg(f: () -> Unit) = thread { try { f() } catch (e: Throwable) { say("Error: ${e.message}") } }
    private fun say(s: String) = runOnUiThread { log.append(s + "\n") }

    private fun pickExcluded() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinct().sortedBy { it.second.lowercase() }
        val ex = sp.getStringSet("ex", emptySet())!!.toMutableSet()
        AlertDialog.Builder(this).setTitle("Apps protegidas (nunca se cierran)")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in ex }) { _, i, c ->
                if (c) ex += apps[i].first else ex -= apps[i].first
            }
            .setPositiveButton("Guardar") { _, _ -> sp.edit().putStringSet("ex", ex).apply() }.show()
    }
}
