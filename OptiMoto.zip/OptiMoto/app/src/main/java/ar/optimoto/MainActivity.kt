package ar.optimoto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val adb by lazy { Adb.get(this) }
    private lateinit var log: TextView
    private lateinit var swAgr: Switch
    private lateinit var swKill: Switch
    private val sp by lazy { getSharedPreferences("p", 0) }
    private val protect = listOf("com.android.systemui", "com.android.phone", "com.android.launcher",
        "com.motorola.launcher", "com.google.android.inputmethod", "android.", "vendor.", "system", "media.")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        swAgr = Switch(this).apply { text = "Liberación agresiva" }
        swKill = Switch(this).apply { text = "Cerrar procesos en caché (salvo protegidas)" }
        log = TextView(this).apply { textSize = 13f }
        listOf<View>(
            btn("1) Emparejar (abre ajustes)") {
                startForegroundService(Intent(this, PairService::class.java))
                say("Activá Depuración inalámbrica y tocá «Vincular dispositivo con código». Saldrá una notificación para escribir el código.")
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { say("Abrí Ajustes › Opciones de desarrollador a mano.") }
            },
            btn("2) Conectar") { bg { say(if (ensure()) "Conectado ✅" else "No se pudo conectar") } },
            swAgr, swKill,
            btn("⚡ Optimizar RAM ahora") { val a = swAgr.isChecked; val k = swKill.isChecked; bg { ensure(); optimize(a, k) } },
            btn("🔧 Recompilar apps (dexopt)") { bg { ensure(); compile() } },
            btn("🛡 Apps protegidas") { pickExcluded() }
        ).forEach { root.addView(it) }
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)
        say("RAM libre: ${freeMb()} MB")
    }

    private fun ensure(): Boolean {
        if (!adb.isConnected) adb.connectTls(this, 8000)
        return adb.isConnected
    }

    private fun bg(f: () -> Unit) = thread { try { f() } catch (e: Throwable) { say("Error: ${e.message}") } }
    private fun say(s: String) = runOnUiThread { log.append(s + "\n") }
    private fun freeMb(): Long = File("/proc/meminfo").readLines()
        .first { it.startsWith("MemAvailable") }.filter { it.isDigit() }.toLong() / 1024

    private fun optimize(aggressive: Boolean, kill: Boolean) {
        val before = freeMb()
        val top = Regex("""\s([\w.]+)/""").find(adb.sh("dumpsys activity activities | grep -m1 topResumedActivity"))?.groupValues?.get(1)
        val ex = sp.getStringSet("ex", emptySet())!!
        val procs = adb.sh("ps -A -o NAME").lines().map { it.trim() }.filter { p ->
            p.contains('.') && !p.contains(' ') && !p.startsWith("/") && !p.startsWith("[") &&
                protect.none { p.startsWith(it) } && p.substringBefore(':') != top && p.substringBefore(':') != packageName
        }.distinct()
        procs.chunked(20).forEach { ch ->
            adb.sh(ch.joinToString(";") { p ->
                val lvl = if (p.substringBefore(':') in ex) "BACKGROUND" else if (aggressive) "COMPLETE" else "MODERATE"
                "am send-trim-memory --user 0 $p $lvl"
            })
        }
        if (kill) procs.map { it.substringBefore(':') }.distinct().filter { it !in ex }
            .chunked(20).forEach { ch -> adb.sh(ch.joinToString(";") { "am kill $it" }) }
        Thread.sleep(2500)
        say("${procs.size} procesos recortados. RAM libre: $before → ${freeMb()} MB")
    }

    private fun compile() {
        say("Compilando apps… dejá el cel cargando, tarda varios minutos.")
        adb.sh("cmd package compile -m speed-profile -a")
        say("Listo.")
    }

    private fun pickExcluded() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinct().sortedBy { it.second.lowercase() }
        val ex = sp.getStringSet("ex", emptySet())!!.toMutableSet()
        AlertDialog.Builder(this).setTitle("Apps protegidas (nunca se cierran)")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in ex }) { _, i, c ->
                if (c) ex += apps[i].first else ex -= apps[i].first
            }
            .setPositiveButton("Guardar") { _, _ -> sp.edit().putStringSet("ex", ex).apply() }.show()
    }
}
