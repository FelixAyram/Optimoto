package ar.optimoto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.concurrent.thread

private val C_BG = 0xFF0F1115.toInt()
private val C_CARD = 0xFF181B22.toInt()
private val C_BTN = 0xFF262A33.toInt()
private val C_ACC = 0xFF4F8CFF.toInt()
private val C_TXT = 0xFFE6E8EC.toInt()
private val C_MUT = 0xFF8A90A0.toInt()

/** Barra de uso de RAM dibujada a mano (sin librerías, casi sin memoria). */
class Bar(c: Context) : View(c) {
    var pct = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val h = height.toFloat(); val w = width.toFloat()
        p.color = C_BTN; cv.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        p.color = C_ACC; cv.drawRoundRect(0f, 0f, w * pct.coerceIn(0, 100) / 100f, h, h / 2, h / 2, p)
    }
}

class MainActivity : Activity() {
    private val sp by lazy { getSharedPreferences("p", 0) }
    private val ui = Handler(Looper.getMainLooper())
    private val lines = ArrayList<String>()
    private val everyOpts = intArrayOf(5, 10, 15, 30, 60, 120)

    private lateinit var tvFree: TextView
    private lateinit var tvSub: TextView
    private lateinit var tvConn: TextView
    private lateinit var bar: Bar
    private lateinit var tvProt: TextView
    private lateinit var tvClose: TextView
    private lateinit var btnEvery: Button
    private lateinit var log: TextView
    private lateinit var swAgr: Switch
    private lateinit var swKill: Switch
    private lateinit var swAuto: Switch
    private lateinit var swScr: Switch
    private lateinit var swNew: Switch
    private lateinit var swCloseOn: Switch
    private lateinit var swBg: Switch
    private lateinit var swAnim: Switch
    private lateinit var etRam: EditText
    private lateinit var etPsi: EditText
    private lateinit var etCpu: EditText

    private val tick = object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 3000) } }

    // ---------- helpers de UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun tv(t: String, size: Float = 14f, color: Int = C_TXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun label(t: String) = tv(t.uppercase(), 11f, C_MUT, true).apply { letterSpacing = 0.08f; setPadding(0, 0, 0, dp(6)) }
    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
        background = round(C_CARD, 16); layoutParams = lp(12); v.forEach { addView(it) }
    }
    private fun btn(t: String, primary: Boolean = false, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 14f; stateListAnimator = null
        background = round(if (primary) C_ACC else C_BTN, 12); minHeight = dp(46); minimumHeight = dp(46)
        layoutParams = lp(8); setOnClickListener { f() }
    }
    private fun sw(t: String, k: String, d: Boolean) = Switch(this).apply {
        text = t; setTextColor(C_TXT); textSize = 14f; isChecked = sp.getBoolean(k, d); setPadding(0, dp(6), 0, dp(6)); layoutParams = lp()
    }
    private fun et(k: String, d: Int) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER; setText(sp.getInt(k, d).toString()); setTextColor(C_TXT); textSize = 14f
        gravity = Gravity.END; background = round(C_BTN, 8); setPadding(dp(10), dp(6), dp(10), dp(6))
        layoutParams = LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    private fun row(t: String, v: View) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(6)
        addView(tv(t).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }); addView(v)
    }
    private fun pair(a: View, b: View) = LinearLayout(this).apply {
        layoutParams = lp()
        a.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4); topMargin = dp(8) }
        b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4); topMargin = dp(8) }
        addView(a); addView(b)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        window.statusBarColor = C_BG; window.navigationBarColor = C_BG

        tvFree = tv("—", 30f, C_TXT, true)
        tvSub = tv("", 12f, C_MUT)
        tvConn = tv("", 12f, C_MUT)
        bar = Bar(this).apply { layoutParams = lp(8).apply { height = dp(8) } }
        tvProt = tv(names("ex"), 13f, C_MUT).apply { layoutParams = lp(2) }
        tvClose = tv(names("close"), 13f, C_MUT).apply { layoutParams = lp(2) }
        btnEvery = btn("Cada ${everyLabel(sp.getInt("closeMin", 30))}") { pickEvery() }
        swAgr = sw("Liberación agresiva", "agr", false)
        swKill = sw("Cerrar procesos en caché (no protegidas)", "kill", false)
        swAuto = sw("Modo automático", "auto", false)
        swScr = sw("Limpiar al apagar la pantalla", "screenoff", false)
        swNew = sw("Compilar apps nuevas al instalarlas", "newcomp", true)
        swCloseOn = sw("Cierre forzado periódico", "closeOn", false)
        swBg = sw("Impedir que se reabran solas", "bgblock", false)
        swAnim = sw("Animaciones en 0", "animOn", false)
        etRam = et("ram", 700); etPsi = et("psi", 10); etCpu = et("cpu", 90)
        log = tv("", 11f, C_MUT).apply { typeface = Typeface.MONOSPACE }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(28)) }
        col.addView(tv("OptiMoto", 26f, C_TXT, true))
        col.addView(tv("Libera RAM por ADB inalámbrico sin matar apps", 13f, C_MUT))
        col.addView(card(label("Estado"), tvFree, bar, tvSub.apply { layoutParams = lp(8) }, tvConn.apply { layoutParams = lp(2) }))
        col.addView(card(label("Conexión"),
            pair(btn("Emparejar") {
                startForegroundService(Intent(this, PairService::class.java))
                say("Activá Depuración inalámbrica y tocá «Vincular dispositivo con código»: saldrá una notificación para escribir el código.")
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { say("Abrí Ajustes › Opciones de desarrollador.") }
            }, btn("Conectar") { bg { Optimizer.ensure(this); say("Conectado."); ui.post { refresh() } } }),
            tv("Emparejar es solo la primera vez. Después alcanza con Conectar.", 12f, C_MUT).apply { layoutParams = lp(8) }))
        col.addView(card(label("Optimizar"),
            btn("Optimizar ahora", true) { saveCfg(); bg { say("Optimizando…"); say(Optimizer.run(this, swAgr.isChecked, swKill.isChecked)); ui.post { refresh() } } },
            swAgr, swKill))
        col.addView(card(label("Automático"), swAuto,
            row("Liberar si la RAM libre baja de (MB)", etRam),
            row("o la presión de memoria pasa de (%)", etPsi),
            row("o el CPU pasa de (%)", etCpu), swScr, swNew))
        col.addView(card(label("Apps protegidas"),
            tv("Nunca se cierran; solo reciben una liberación suave.", 12f, C_MUT), tvProt,
            btn("Editar lista") { pickApps("Apps protegidas", "ex") { tvProt.text = names("ex"); bg { Optimizer.syncBackground(this) } } }))
        col.addView(card(label("Cierre forzado"), swCloseOn,
            tv("Cierra por completo estas apps, incluso en segundo plano. No toca la que estás usando.", 12f, C_MUT), tvClose,
            pair(btn("Editar lista") { pickApps("Apps a cerrar", "close") { tvClose.text = names("close"); bg { Optimizer.syncBackground(this) } } }, btnEvery),
            swBg))
        col.addView(card(label("Rendimiento"), swAnim,
            tv("Al apagarlo vuelven a como estaban antes.", 12f, C_MUT),
            pair(btn("Diagnóstico") { bg { diag() } },
                btn("Recompilar todo") { bg { say("Compilando… dejá el cel cargando, tarda varios minutos."); Optimizer.sh(this, "cmd package compile -m speed-profile -a"); say("Listo.") } })))
        col.addView(card(label("Widget"), tv("Mantené apretada la pantalla de inicio › Widgets › OptiMoto. Un toque optimiza y muestra el resultado.", 12f, C_MUT)))
        col.addView(card(label("Registro"), log))
        setContentView(ScrollView(this).apply { setBackgroundColor(C_BG); isFillViewport = true; addView(col) })

        swAuto.setOnCheckedChangeListener { _, _ -> syncService() }
        swCloseOn.setOnCheckedChangeListener { _, _ -> syncService() }
        swBg.setOnCheckedChangeListener { _, _ -> saveCfg(); bg { Optimizer.syncBackground(this); say("Segundo plano actualizado.") } }
        swAnim.setOnCheckedChangeListener { _, on ->
            bg {
                if (on) Optimizer.animationsOff(this) else Optimizer.animationsRestore(this)
                sp.edit().putBoolean("animOn", on).apply()
                say(if (on) "Animaciones en 0." else "Animaciones restablecidas.")
            }
        }
        if (swAuto.isChecked || swCloseOn.isChecked) syncService()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { ui.removeCallbacks(tick); saveCfg(); super.onPause() }
    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) Runtime.getRuntime().gc() }

    private fun refresh() {
        val t = Optimizer.totalMb(); val f = Optimizer.freeMb()
        tvFree.text = "${Optimizer.fmt(f)} libres"
        bar.pct = if (t > 0) ((t - f) * 100 / t).toInt() else 0; bar.invalidate()
        tvSub.text = Optimizer.statusLine() + "\nOptiMoto usa ${Debug.getPss() / 1024} MB"
        tvConn.text = if (Adb.isUp()) "ADB conectado" else "ADB sin conexión"
    }

    private fun syncService() {
        saveCfg()
        val i = Intent(this, AutoService::class.java)
        if (sp.getBoolean("auto", false) || sp.getBoolean("closeOn", false)) startForegroundService(i) else stopService(i)
    }

    private fun saveCfg() {
        sp.edit().putBoolean("agr", swAgr.isChecked).putBoolean("kill", swKill.isChecked).putBoolean("auto", swAuto.isChecked)
            .putBoolean("screenoff", swScr.isChecked).putBoolean("newcomp", swNew.isChecked).putBoolean("closeOn", swCloseOn.isChecked)
            .putBoolean("bgblock", swBg.isChecked)
            .putInt("ram", etRam.text.toString().toIntOrNull() ?: 700).putInt("psi", etPsi.text.toString().toIntOrNull() ?: 10)
            .putInt("cpu", etCpu.text.toString().toIntOrNull() ?: 90).apply()
    }

    private fun everyLabel(m: Int) = if (m >= 60) "${m / 60} h" else "$m min"

    private fun pickEvery() {
        val cur = everyOpts.indexOf(sp.getInt("closeMin", 30)).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Cerrar cada…")
            .setSingleChoiceItems(everyOpts.map { everyLabel(it) }.toTypedArray(), cur) { d, i ->
                sp.edit().putInt("closeMin", everyOpts[i]).apply(); btnEvery.text = "Cada ${everyLabel(everyOpts[i])}"; d.dismiss()
            }.show()
    }

    private fun names(key: String): String {
        val set = sp.getStringSet(key, emptySet())!!
        if (set.isEmpty()) return "Ninguna"
        val pm = packageManager
        val n = set.map { p -> try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p } }.sorted()
        return if (n.size > 8) n.take(8).joinToString(", ") + " y ${n.size - 8} más" else n.joinToString(", ")
    }

    private fun pickApps(title: String, key: String, after: () -> Unit) {
        val pm = packageManager
        val sel = sp.getStringSet(key, emptySet())!!.toMutableSet()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinct()
            .sortedWith(compareBy({ it.first !in sel }, { it.second.lowercase() }))
        AlertDialog.Builder(this).setTitle(title)
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in sel }) { _, i, c ->
                if (c) sel += apps[i].first else sel -= apps[i].first
            }
            .setPositiveButton("Guardar") { _, _ -> sp.edit().putStringSet(key, sel).apply(); after() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun diag() {
        say(Optimizer.statusLine())
        val st = Optimizer.stats(this)
        say("Presión de memoria: ${st?.memPsi ?: "n/d"}% · CPU: ${st?.cpu ?: "n/d"}%")
        val top = Optimizer.sh(this, "ps -A -o RSS,NAME | sort -rn | head -8").lines().mapNotNull { l ->
            val t = l.trim().split(Regex("\\s+"), 2); val kb = t.getOrNull(0)?.toLongOrNull()
            if (kb != null && t.size == 2) "${kb / 1024} MB  ${t[1]}" else null
        }
        say("Más pesados:\n" + top.joinToString("\n"))
    }

    private fun bg(f: () -> Unit) = thread { try { f() } catch (e: Throwable) { say("Error: ${e.message}") } }

    private fun say(s: String) = runOnUiThread {
        lines.add(s); while (lines.size > 25) lines.removeAt(0)
        log.text = lines.joinToString("\n")
    }
}
