plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ar.optimoto"
    compileSdk = 34
    defaultConfig { applicationId = "ar.optimoto"; minSdk = 26; targetSdk = 33; versionCode = 2; versionName = "2.0" }
    signingConfigs {
        create("opti") { storeFile = file("optimoto.jks"); storePassword = "optimoto"; keyAlias = "opti"; keyPassword = "optimoto" }
    }
    buildTypes {
        // Se compila "debug" pero sin modo depuración y con firma fija: más liviano y se actualiza encima.
        debug { isDebuggable = false; signingConfig = signingConfigs.getByName("opti") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("opti") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.github.MuntashirAkon:libadb-android:3.1.1")
    implementation("com.github.MuntashirAkon:sun-security-android:1.1")
    implementation("org.conscrypt:conscrypt-android:2.5.3")
}
