plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ar.optimoto"
    compileSdk = 34
    defaultConfig { applicationId = "ar.optimoto"; minSdk = 26; targetSdk = 33; versionCode = 1; versionName = "1.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.github.MuntashirAkon:libadb-android:3.1.1")
    implementation("com.github.MuntashirAkon:sun-security-android:1.1")
    implementation("org.conscrypt:conscrypt-android:2.5.3")
}
